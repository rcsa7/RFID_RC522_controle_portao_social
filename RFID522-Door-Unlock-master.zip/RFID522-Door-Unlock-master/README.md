2017 Announcement:
I am happy to announce new project
https://github.com/omersiar/esp-rfid
ESP-RFID Access Control with ESP8266

Arduino RC522 RFID Access Control
=======
July/2014 Omer Siar Baysal

--------

Arduino RFID Access Control using a RC522 RFID 
reader with SPI interface on your Arduino

For now there is 3 version of Access Control

**EEPROM Version**

Storing data on EEPROM, Stable, Basic System

**SD Version - Work In Progress**

Storing data on SD Card, more features will be added like 
USER management
Tracking with Real Time Clock

**Embedded System - Work In Progress**

Complete RFID solution with
Networked Web Interface
USER management
Tracking with Real Time Clock
Cross-Platform Management Application

More info on: 
http://forum.arduino.cc/index.php?topic=256260
