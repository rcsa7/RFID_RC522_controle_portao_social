String checkup(String cardNo)
{
  String personName;
 
  if (cardNo.substring(1) == "D9 14 B0 A3") { personName = " MONICA"; }  
  else if (cardNo.substring(1) == "9A F2 56 15") { personName = "CHAVEIRO2"; }  
  else if (cardNo.substring(1) == "09 D0 F6 98") { personName = "CHAVEIRO3"; }
  else if (cardNo.substring(1) == "F9 27 BD A3") { personName = "CHAVEIRO4"; } 
 
  else personName = " Acesso Negado! " ;

 

  return personName;
 
}
